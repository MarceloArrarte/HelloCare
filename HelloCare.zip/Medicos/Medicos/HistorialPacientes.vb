﻿Public Class HistorialPacientes

End Class